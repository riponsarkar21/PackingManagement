from flask_socketio import SocketIO
import subprocess
import threading

socketio = SocketIO()  # Initialize a SocketIO instance without the app context

def sync_data():
    def run_script():
        try:
            # Run the script in a separate thread
            process = subprocess.Popen(
                ['python', 'Dashboard_Server_Handler V 06.py'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            total_files = 11  # Adjust this to the actual number of files being copied
            copied_files = 0
            
            while True:
                output = process.stdout.readline()
                if output == b"" and process.poll() is not None:
                    break
                if output:
                    print(output.strip().decode())  # Optionally print output for debugging
                    copied_files += 1
                    socketio.emit('progress', {'progress': (copied_files / total_files) * 100})
            
            process.wait()  # Wait for the process to finish
            socketio.emit('progress', {'progress': 100})  # Mark completion
        except Exception as e:
            socketio.emit('error', {'message': str(e)})

    threading.Thread(target=run_script).start()
